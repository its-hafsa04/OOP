//Create a base class Animal with a method makeSound(). Derive two classes Dog and Cat from Animal and override the 
//makeSound() method to represent the sound each animal makes. Handle exception when access wrong function of makesound.
#include <iostream>
#include <stdexcept>
using namespace std;
class Animal {
public:
    virtual void makeSound() {
        throw logic_error("Invalid function call. Use overridden function in derived classes.");
    }
};

class Dog : public Animal {
public:
    void makeSound(){
        cout << "Dog barks: Woof! Woof!" << endl;
    }
};

class Cat : public Animal {
public:
    void makeSound(){
        cout << "Cat meows: Meow! Meow!" << endl;
    }
};

int main() {
    try {
        // Example usage with Dog
        Dog myDog;
        myDog.makeSound();

        // Example usage with Cat
        Cat myCat;
        myCat.makeSound();

        // Attempt to call makeSound on the base class (should throw an exception)
        Animal genericAnimal;
        genericAnimal.makeSound();

    } catch (const logic_error& e) {
        // Handle the exception for an invalid function call
        cerr << "Error: " << e.what() << endl;
    }

    return 0;
}

